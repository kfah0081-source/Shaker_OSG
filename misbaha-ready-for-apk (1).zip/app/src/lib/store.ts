export type Profile = { id: string; text: string; target: number; meaning: string; effect: string; fTheta: number; tMid: number; custom?: boolean; mode?: 'whisper' | 'loud' }
export type Session = { ts: number; id: string; sec: number; count: number; eff: number; avgF: number; mode?: 'whisper' | 'loud'; manual?: boolean }

export const BASE: Profile[] = [
  { id: 'subhan', text: 'سُبْحَانَ الله', target: 33, meaning: 'تنزيه وتعظيم', effect: 'هدوء وتخفيف التوتر', fTheta: 6, tMid: 6 },
  { id: 'hamd', text: 'الْحَمْدُ لِلَّه', target: 33, meaning: 'شكر وامتنان', effect: 'استرخاء ومزاج إيجابي', fTheta: 8.5, tMid: 5 },
  { id: 'akbar', text: 'اللهُ أَكْبَر', target: 34, meaning: 'عظمة وقوة', effect: 'يقظة هادئة وثبات', fTheta: 10, tMid: 4 },
  { id: 'tahlil', text: 'لَا إِلَهَ إِلَّا الله', target: 100, meaning: 'توحيد وتركيز', effect: 'صفاء وتركيز عميق', fTheta: 5.5, tMid: 6 },
  { id: 'istighfar', text: 'أَسْتَغْفِرُ الله', target: 100, meaning: 'رجوع وتخفف', effect: 'تفريغ وراحة', fTheta: 6.5, tMid: 5 },
  { id: 'salawat', text: 'اللَّهُمَّ صَلِّ عَلَى مُحَمَّد', target: 100, meaning: 'محبة وصلة', effect: 'سكينة ودفء', fTheta: 7.5, tMid: 5 },
]
export const KINDS = {
  calm: { l: 'تأمل عميق', fTheta: 5.5, tMid: 6, effect: 'استغراق وصفاء' },
  soft: { l: 'هدوء متوازن', fTheta: 8, tMid: 5, effect: 'استرخاء يقظ' },
  alert: { l: 'يقظة هادئة', fTheta: 10, tMid: 4, effect: 'تركيز وثبات' },
}
export const THEMES: [string, string][] = [['', 'الافتراضي'], ['intel', 'استخباراتي'], ['sec', 'أمني'], ['lead', 'قيادي'], ['calm', 'سكينة وطمأنينة']]

export function load<T>(k: string, d: T): T {
  try { const v = localStorage.getItem('msb:' + k); return v ? JSON.parse(v) : d } catch { return d }
}
export function save(k: string, v: unknown) {
  try { localStorage.setItem('msb:' + k, JSON.stringify(v)) } catch { /* ignore */ }
}

export function stats(ss: Session[], days: number) {
  const now = new Date()
  const since = days === 1 ? new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime() : Date.now() - days * 864e5
  const f = ss.filter((s) => s.ts >= since)
  const sec = f.reduce((a, s) => a + s.sec, 0)
  const days_ = new Set(f.map((s) => new Date(s.ts).toDateString())).size
  return {
    min: sec / 60,
    avgF: sec ? f.reduce((a, s) => a + s.avgF * s.sec, 0) / sec : 0,
    consistency: Math.round((days_ / days) * 100),
  }
}
