// نموذج استرشادي لرحلة ترددات الدماغ أثناء التسبيح المتواصل
// ملاحظة: نموذج تعليمي تقريبي مبني على أدبيات التأمل والاسترخاء، وليس قياساً طبياً فعلياً.

export type Band = 'beta' | 'alpha' | 'theta'

export const F_BETA = 19.5 // نقطة البداية: يقظة نشطة (هرتز)
export const F_THETA = 5.5 // قاع الرحلة: استغراق عميق (هرتز)
export const T_MID = 6 // منتصف الانتقال تقريباً (دقيقة)
export const K_SIG = 2.1 // انحدار الانتقال
export const P_MAX = 45 // أقصى أثر متوقع بعد التوقف (دقيقة)
export const TAU_BUILD = 9 // ثابت بناء الأثر مع الزمن (دقيقة)

/** التردد الغالب المتوقع بعد t دقيقة من التسبيح المتواصل */
export const active = { fTheta: F_THETA, tMid: T_MID }
export function freqAt(tMin: number, fT = active.fTheta, tm = active.tMid): number {
  return fT + (F_BETA - fT) / (1 + Math.exp((tMin - tm) / K_SIG))
}

/** عمق الحالة 0..1 (0 = بيتا صرفة، 1 = ثيتا صرفة) */
export function depthAt(tMin: number): number {
  return (F_BETA - freqAt(tMin)) / (F_BETA - active.fTheta)
}

export function bandOf(freq: number): Band {
  if (freq >= 13) return 'beta'
  if (freq >= 8) return 'alpha'
  return 'theta'
}

/**
 * طول الأثر المتوقع (بالدقائق) لو توقفت عند اللحظة t.
 * ينمو مع عمق الحالة المُحقَّق ومع مدة المكوث فيها، ويتشبع عند P_MAX.
 */
export function persistenceAt(tMin: number): number {
  if (tMin <= 0) return 0
  const d = depthAt(tMin)
  return P_MAX * Math.pow(d, 1.25) * (1 - Math.exp(-tMin / TAU_BUILD))
}

/**
 * منحنى زوال الأثر بعد التوقف عند tStop:
 * يعيد s دقيقة بعد التوقف الترددَ المتوقع في تلك اللحظة.
 */
export function recoveryFreqAt(tStop: number, sAfter: number): number {
  const f0 = freqAt(tStop)
  const p = persistenceAt(tStop)
  const tau = Math.max(p / 3, 0.4)
  const f = f0 + (F_BETA - f0) * (1 - Math.exp(-sAfter / tau))
  return Math.min(f, F_BETA)
}

export const BAND_META: Record<
  Band,
  { ar: string; range: string; color: string; tint: string; desc: string }
> = {
  beta: {
    ar: 'بيتا',
    range: '13–30 هرتز',
    color: '#d98a6a',
    tint: 'rgba(217,138,106,0.10)',
    desc: 'يقظة وتفكير نشط — نقطة البداية المعتادة',
  },
  alpha: {
    ar: 'ألفا',
    range: '8–13 هرتز',
    color: '#d4b67e',
    tint: 'rgba(212,182,126,0.10)',
    desc: 'استرخاء يقظ وهدوء داخلي متزايد',
  },
  theta: {
    ar: 'ثيتا',
    range: '4–8 هرتز',
    color: '#5ba8a0',
    tint: 'rgba(91,168,160,0.12)',
    desc: 'استغراق عميق وصفاء — هدف الرحلة',
  },
}

/** تحويل الأرقام إلى أرقام عربية مشرقية */
export function arNum(n: number, digits = 0): string {
  return n
    .toFixed(digits)
    .replace(/\d/g, (d) => '0123456789'[+d])
    .replace('.', '.')
}

/** تنسيق المدة مم:ثث بأرقام عربية */
export function arClock(totalSec: number): string {
  const m = Math.floor(totalSec / 60)
  const s = Math.floor(totalSec % 60)
  return `${arNum(m)}:${arNum(s).padStart(2, '0')}`
}
