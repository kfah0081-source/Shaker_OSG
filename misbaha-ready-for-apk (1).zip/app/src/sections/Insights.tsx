import { useMemo, useState } from 'react'
import type { Dhikr, TracePoint } from '@/hooks/useDhikrSession'
import { bandOf } from '@/lib/model'

type Props = {
  trace: TracePoint[]
  elapsedSec: number
  rhythm: { avg: number; reg: number }
  total: number
  adhkar: Dhikr[]
  onUndo: () => void
  onManual: (id: string, n: number, min: number, ts: number, mode: 'whisper' | 'loud') => void
}

const fmt = (m: number) => `${m.toFixed(1)} min`
const LEVELS = ['منخفض', 'متوسط', 'جيد', 'مرتفع']

export default function Insights({ trace, elapsedSec, rhythm, total, adhkar, onUndo, onManual }: Props) {
  const [id, setId] = useState(adhkar[0].id)
  const [n, setN] = useState(33)
  const [min, setMin] = useState(5)
  const [day, setDay] = useState(() => new Date().toISOString().slice(0, 16))
  const [mode, setMode] = useState<'whisper' | 'loud'>('loud')

  const bands = useMemo(() => {
    const b = { beta: 0, alpha: 0, theta: 0 }
    for (let i = 1; i < trace.length; i++) b[bandOf(trace[i].f)] += trace[i].t - trace[i - 1].t
    return b
  }, [trace])

  const score = Math.min(100, rhythm.reg * 0.4 + Math.min(bands.theta / 6, 1) * 40 + Math.min(elapsedSec / 900, 1) * 20)
  const level = LEVELS[score < 25 ? 0 : score < 50 ? 1 : score < 75 ? 2 : 3]
  const box = 'flex flex-col gap-3 rounded-xl border hairline p-5'
  const inp = 'rounded-lg border hairline bg-transparent px-3 py-2 text-sm text-[--ink] outline-none'
  const h = 'font-display text-xl text-[#d4b67e]'

  return (
    <section className="grid gap-6 py-12 md:grid-cols-2">
      <div className={box}>
        <h3 className={h}>تحليل الجلسة الحالية</h3>
        {([['Beta', bands.beta], ['Alpha', bands.alpha], ['Theta', bands.theta]] as [string, number][]).map(([l, v]) => (
          <div key={l} className="flex justify-between text-sm text-[--ink-dim]"><span>{l}</span><span className="tabular-nums">{fmt(v)}</span></div>
        ))}
        <div className="flex justify-between text-sm text-[--ink-dim]"><span>متوسط الفاصل بين النقرات</span><span className="tabular-nums">{rhythm.avg ? rhythm.avg.toFixed(2) + ' s' : '-'}</span></div>
        <div className="flex justify-between text-sm text-[--ink-dim]"><span>الانتظام</span><span className="tabular-nums">{rhythm.reg}%</span></div>
        <div className="flex justify-between text-sm text-[--ink-dim]"><span>تنشيط العصب المبهم المتوقع</span><span>{total ? level : '-'}</span></div>
        <button onClick={onUndo} disabled={!total} className="rounded-lg border hairline py-2 text-sm text-[--ink-dim] disabled:opacity-40">↶ تراجع عن آخر ضغطة</button>
        <p className="text-xs leading-relaxed text-[--ink-faint]">جميع الترددات ومؤشر العصب المبهم والأثر تقديرات ومحاكاة تعليمية غير طبية، وليست قياسًا فعليًا لنشاط الدماغ ولا تشخيصًا أو نصيحة طبية.</p>
      </div>

      <div className={box}>
        <h3 className={h}>إضافة جلسة تمت خارج التطبيق</h3>
        <select value={id} onChange={(e) => setId(e.target.value)} className={inp + ' bg-[#101e2c]'}>
          {adhkar.map((d) => <option key={d.id} value={d.id}>{d.text}</option>)}
        </select>
        <div className="flex gap-3">
          <label className="flex flex-1 flex-col gap-1 text-xs text-[--ink-faint]">العدد<input type="number" min={1} value={n} onChange={(e) => setN(Math.max(1, +e.target.value || 1))} className={inp} /></label>
          <label className="flex flex-1 flex-col gap-1 text-xs text-[--ink-faint]">المدة (دقيقة)<input type="number" min={1} value={min} onChange={(e) => setMin(Math.max(1, +e.target.value || 1))} className={inp} /></label>
        </div>
        <input type="datetime-local" value={day} onChange={(e) => setDay(e.target.value)} className={inp} />
        <select value={mode} onChange={(e) => setMode(e.target.value as 'whisper' | 'loud')} className={inp + ' bg-[#101e2c]'}>
          <option value="loud">جهرًا</option><option value="whisper">همسًا</option>
        </select>
        <button onClick={() => onManual(id, n, min, new Date(day).getTime() || Date.now(), mode)} className="rounded-lg border border-[#d4b67e]/60 py-2 text-sm text-[#fce1b6]">إضافة إلى الإحصائيات</button>
        <p className="text-xs text-[--ink-faint]">تُحاكى الجلسة بمتوسط نموذج هذا الذكر وتُضاف إلى إحصائياتك.</p>
      </div>
    </section>
  )
}
