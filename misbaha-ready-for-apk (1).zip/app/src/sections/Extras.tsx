import { useEffect, useState } from 'react'
import type { Dhikr } from '@/hooks/useDhikrSession'
import { KINDS, THEMES, load, save, stats, type Session } from '@/lib/store'

type Props = {
  adhkar: Dhikr[]
  sessions: Session[]
  goal: number
  onGoal: (n: number) => void
  onAdd: (text: string, target: number, kind: keyof typeof KINDS, meaning?: string, mode?: 'whisper' | 'loud') => void
}

export default function Extras({ adhkar, sessions, goal, onGoal, onAdd }: Props) {
  const [theme, setTheme] = useState<string>(() => load('theme', ''))
  const [text, setText] = useState('')
  const [tg, setTg] = useState(33)
  const [meaning, setMeaning] = useState('')
  const [mode, setMode] = useState<'whisper' | 'loud'>('loud')
  const [kind, setKind] = useState<keyof typeof KINDS>('soft')
  useEffect(() => { document.documentElement.dataset.theme = theme; save('theme', theme) }, [theme])

  const box = 'flex flex-col gap-3 rounded-xl border hairline p-5'
  const inp = 'rounded-lg border hairline bg-transparent px-3 py-2 text-sm text-[--ink] outline-none'
  const h = 'font-display text-xl text-[#d4b67e]'
  const rows: [string, number][] = [['اليوم', 1], ['الأسبوع', 7], ['الشهر', 30]]

  return (
    <section className="grid gap-6 py-12 md:grid-cols-2">
      <div className={box}>
        <h3 className={h}>المظهر</h3>
        <div className="flex flex-wrap gap-2">
          {THEMES.map(([k, l]) => (
            <button key={k} onClick={() => setTheme(k)} className={`rounded-full border px-4 py-1.5 text-sm ${theme === k ? 'border-[#d4b67e]/70 text-[#fce1b6]' : 'hairline text-[--ink-dim]'}`}>{l}</button>
          ))}
        </div>
        <h3 className={h + ' mt-3'}>هدف الأثر والتذكيرات</h3>
        <label className="flex items-center gap-3 text-sm text-[--ink-dim]">
          الأثر المستهدف (دقيقة، حتى 45)
          <input type="number" min={5} max={45} value={goal} onChange={(e) => onGoal(Math.min(45, Math.max(5, +e.target.value || 5)))} className={inp + ' w-20'} />
        </label>
        <p className="text-xs text-[--ink-faint]">تنبيه عند بلوغ 50% ثم 90% ثم اكتمال الأثر المستهدف.</p>
      </div>

      <div className={box}>
        <h3 className={h}>إضافة ذكر</h3>
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="نص الذكر" className={inp} />
        <input value={meaning} onChange={(e) => setMeaning(e.target.value)} placeholder="معنى الذكر (اختياري)" className={inp} />
        <select value={mode} onChange={(e) => setMode(e.target.value as 'whisper' | 'loud')} className={inp + ' bg-[#101e2c]'}>
          <option value="loud">جهرًا</option><option value="whisper">همسًا</option>
        </select>
        <div className="flex gap-3">
          <input type="number" min={1} value={tg} onChange={(e) => setTg(Math.max(1, +e.target.value || 1))} className={inp + ' w-24'} />
          <select value={kind} onChange={(e) => setKind(e.target.value as keyof typeof KINDS)} className={inp + ' flex-1 bg-[#101e2c]'}>
            {Object.entries(KINDS).map(([k, v]) => <option key={k} value={k}>{v.l} (≈{v.fTheta} Hz)</option>)}
          </select>
        </div>
        <button onClick={() => { if (text.trim()) { onAdd(text.trim(), tg, kind, meaning.trim() || undefined, mode); setText(''); setMeaning('') } }} className="rounded-lg border border-[#d4b67e]/60 py-2 text-sm text-[#fce1b6]">إضافة</button>
      </div>

      <div className={box}>
        <h3 className={h}>الاستقرار والمتوسط</h3>
        {rows.map(([l, d]) => {
          const s = stats(sessions, d)
          return (
            <div key={l} className="flex justify-between text-sm text-[--ink-dim]">
              <span>{l}</span>
              <span className="tabular-nums">{s.min.toFixed(1)} min · {s.avgF ? s.avgF.toFixed(1) : '-'} Hz · {s.consistency}%</span>
            </div>
          )
        })}
        <p className="text-xs text-[--ink-faint]">الاستقرار = نسبة الأيام النشطة، والتردد متوسط مرجّح بالزمن.</p>
      </div>

      <div className={box}>
        <h3 className={h}>آخر جلسة لكل ذكر</h3>
        {adhkar.map((d) => {
          const l = [...sessions].reverse().find((s) => s.id === d.id)
          return (
            <div key={d.id} className="flex justify-between gap-3 text-sm text-[--ink-dim]">
              <span>{d.text}</span>
              <span className="tabular-nums">{l ? `${l.eff.toFixed(1)} / ${goal} min (${Math.round((l.eff / goal) * 100)}%) · ${new Date(l.ts).toLocaleDateString('en-GB')}` : '-'}</span>
            </div>
          )
        })}
      </div>
    </section>
  )
}
