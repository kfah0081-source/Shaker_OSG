import { useMemo, useState } from 'react'
import {
  BAND_META,
  P_MAX,
  arNum,
  bandOf,
  freqAt,
  persistenceAt,
  recoveryFreqAt,
} from '@/lib/model'
import type { TracePoint } from '@/hooks/useDhikrSession'

type Props = {
  elapsedSec: number
  trace: TracePoint[]
}

const W = 760
const H = 380
const ML = 30 // هامش أعلى
const MR = 56 // هامش يمين (لتسميات النطاقات)
const MT = 20
const MB = 38
const Y_MAX = 24

export default function JourneyChart({ elapsedSec, trace }: Props) {
  const [mode, setMode] = useState<'freq' | 'effect'>('freq')

  const tNow = elapsedSec / 60
  const fNow = freqAt(tNow)
  const pNow = persistenceAt(tNow)
  const band = bandOf(fNow)
  const meta = BAND_META[band]

  const xMax = useMemo(() => {
    if (mode === 'freq') return Math.max(15, Math.ceil(tNow + pNow + 4))
    return Math.max(15, Math.ceil(tNow) + 6)
  }, [mode, tNow, pNow])

  const x = (t: number) => MR + (t / xMax) * (W - MR - ML)
  const yF = (f: number) => MT + (1 - f / Y_MAX) * (H - MT - MB)
  const yP = (p: number) => MT + (1 - p / P_MAX) * (H - MT - MB)

  // المنحنى النموذجي الكامل (منقّط خافت)
  const idealPath = useMemo(() => {
    const pts: string[] = []
    for (let t = 0; t <= xMax; t += xMax / 120) {
      pts.push(`${pts.length ? 'L' : 'M'}${x(t).toFixed(1)},${yF(freqAt(t)).toFixed(1)}`)
    }
    return pts.join(' ')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [xMax])

  // مسار الجلسة الفعلي
  const tracePath = useMemo(() => {
    if (!trace.length) return ''
    return trace
      .map((p, i) => `${i ? 'L' : 'M'}${x(p.t).toFixed(1)},${yF(p.f).toFixed(1)}`)
      .join(' ')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [trace, xMax])

  // إسقاط زوال الأثر بعد التوقف الآن
  const recoveryPath = useMemo(() => {
    if (pNow < 0.5) return ''
    const pts: string[] = [`M${x(tNow).toFixed(1)},${yF(fNow).toFixed(1)}`]
    const steps = 40
    for (let i = 1; i <= steps; i++) {
      const s = (pNow * i) / steps
      pts.push(`L${x(tNow + s).toFixed(1)},${yF(recoveryFreqAt(tNow, s)).toFixed(1)}`)
    }
    return pts.join(' ')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tNow, pNow, fNow, xMax])

  // منحنى طول الأثر المتوقع عند كل لحظة استمرار
  const effectPath = useMemo(() => {
    const pts: string[] = []
    for (let t = 0; t <= xMax; t += xMax / 140) {
      pts.push(`${pts.length ? 'L' : 'M'}${x(t).toFixed(1)},${yP(persistenceAt(t)).toFixed(1)}`)
    }
    return pts.join(' ')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [xMax])

  const effectFill = useMemo(() => {
    if (!effectPath) return ''
    return `${effectPath} L${x(xMax).toFixed(1)},${yP(0).toFixed(1)} L${x(0).toFixed(1)},${yP(0).toFixed(1)} Z`
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [effectPath, xMax])

  const xTicks = useMemo(() => {
    const step = xMax > 36 ? 10 : 5
    const ticks: number[] = []
    for (let t = 0; t <= xMax; t += step) ticks.push(t)
    return ticks
  }, [xMax])

  const nowX = x(Math.min(tNow, xMax))

  return (
    <section className="flex flex-col gap-5">
      {/* التبويبات */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex gap-2">
          <button
            onClick={() => setMode('freq')}
            className={`rounded-full border px-5 py-1.5 text-sm transition-all ${
              mode === 'freq'
                ? 'border-[#d4b67e]/70 bg-[#d4b67e]/10 text-[#fce1b6]'
                : 'hairline text-[--ink-dim] hover:text-[#fce1b6]'
            }`}
          >
            رحلة التردد الدماغي
          </button>
          <button
            onClick={() => setMode('effect')}
            className={`rounded-full border px-5 py-1.5 text-sm transition-all ${
              mode === 'effect'
                ? 'border-[#5ba8a0]/70 bg-[#5ba8a0]/10 text-[#9fd4ce]'
                : 'hairline text-[--ink-dim] hover:text-[#9fd4ce]'
            }`}
          >
            طول الأثر المتوقع
          </button>
        </div>
        <span className="hidden text-[11px] text-[--ink-faint] sm:block">
          المحور الأفقي: دقائق التسبيح المتواصل
        </span>
      </div>

      <div dir="ltr" className="w-full overflow-x-auto">
        <svg viewBox={`0 0 ${W} ${H}`} className="min-w-[560px] w-full">
          <defs>
            <linearGradient id="goldTrace" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#d98a6a" />
              <stop offset="55%" stopColor="#d4b67e" />
              <stop offset="100%" stopColor="#5ba8a0" />
            </linearGradient>
            <linearGradient id="effectFillG" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="rgba(91,168,160,0.25)" />
              <stop offset="100%" stopColor="rgba(91,168,160,0)" />
            </linearGradient>
            <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="3.5" result="b" />
              <feMerge>
                <feMergeNode in="b" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {mode === 'freq' ? (
            <>
              {/* نطاقات بيتا / ألفا / ثيتا */}
              <rect x={MR} y={yF(Y_MAX)} width={W - MR - ML} height={yF(13) - yF(Y_MAX)} fill={BAND_META.beta.tint} />
              <rect x={MR} y={yF(13)} width={W - MR - ML} height={yF(8) - yF(13)} fill={BAND_META.alpha.tint} />
              <rect x={MR} y={yF(8)} width={W - MR - ML} height={yF(0) - yF(8)} fill={BAND_META.theta.tint} />

              {/* خطوط فاصلة بين النطاقات */}
              {[13, 8].map((b) => (
                <line key={b} x1={MR} x2={W - ML} y1={yF(b)} y2={yF(b)} stroke="rgba(252,225,182,0.10)" strokeDasharray="3 5" />
              ))}

              {/* تسميات النطاقات (يسار الرسم) */}
              {[
                { b: BAND_META.beta, y: (yF(Y_MAX) + yF(13)) / 2 },
                { b: BAND_META.alpha, y: (yF(13) + yF(8)) / 2 },
                { b: BAND_META.theta, y: (yF(8) + yF(0)) / 2 },
              ].map(({ b, y }) => (
                <text key={b.ar} x={W - ML - 10} y={y + 4} textAnchor="end" fontSize="13" fill={b.color} opacity="0.85" style={{ fontFamily: 'Amiri, serif' }}>
                  {b.ar}
                </text>
              ))}

              {/* شبكة الترددات */}
              {[0, 5, 10, 15, 20].map((f) => (
                <g key={f}>
                  <line x1={MR} x2={W - ML} y1={yF(f)} y2={yF(f)} stroke="rgba(252,225,182,0.05)" />
                  <text x={MR - 6} y={yF(f) + 4} textAnchor="end" fontSize="10" fill="rgba(242,237,226,0.35)">
                    {arNum(f)}
                  </text>
                </g>
              ))}

              {/* المنحنى النموذجي */}
              <path d={idealPath} fill="none" stroke="rgba(252,225,182,0.22)" strokeWidth="1.2" strokeDasharray="2 6" />

              {/* إسقاط زوال الأثر */}
              {recoveryPath && (
                <>
                  <path d={recoveryPath} fill="none" stroke={meta.color} strokeWidth="1.6" strokeDasharray="5 6" opacity="0.7" />
                  <circle cx={x(tNow + pNow)} cy={yF(recoveryFreqAt(tNow, pNow))} r="3.5" fill="none" stroke={meta.color} strokeWidth="1.4" opacity="0.8" />
                  <text
                    x={Math.min(x(tNow + pNow), W - ML - 4)}
                    y={yF(recoveryFreqAt(tNow, pNow)) - 12}
                    textAnchor="end"
                    fontSize="11"
                    fill={meta.color}
                  >
                    يزول الأثر بعد ≈ {arNum(pNow)} د
                  </text>
                </>
              )}

              {/* مسار الجلسة الفعلي */}
              {tracePath && (
                <path d={tracePath} fill="none" stroke="url(#goldTrace)" strokeWidth="2.6" filter="url(#glow)" strokeLinecap="round" />
              )}

              {/* مؤشر اللحظة الحالية */}
              <line x1={nowX} x2={nowX} y1={MT} y2={H - MB} stroke="rgba(252,225,182,0.14)" strokeDasharray="2 4" />
              <circle cx={nowX} cy={yF(fNow)} r="6" fill={meta.color} filter="url(#glow)" />
              <circle cx={nowX} cy={yF(fNow)} r="11" fill="none" stroke={meta.color} strokeWidth="1" opacity="0.4" />
              <text x={nowX} y={MT + 4} textAnchor="middle" fontSize="11" fill={meta.color} style={{ fontFamily: 'Amiri, serif' }}>
                {meta.ar} · {arNum(fNow, 1)} هرتز
              </text>
            </>
          ) : (
            <>
              {/* شبكة دقائق الأثر */}
              {[0, 15, 30, 45].map((p) => (
                <g key={p}>
                  <line x1={MR} x2={W - ML} y1={yP(p)} y2={yP(p)} stroke="rgba(252,225,182,0.06)" />
                  <text x={MR - 6} y={yP(p) + 4} textAnchor="end" fontSize="10" fill="rgba(242,237,226,0.35)">
                    {arNum(p)}
                  </text>
                </g>
              ))}
              <text x={MR - 6} y={MT - 4} textAnchor="end" fontSize="9" fill="rgba(242,237,226,0.3)">
                د
              </text>

              {/* التعبئة والمنحنى */}
              <path d={effectFill} fill="url(#effectFillG)" />
              <path d={effectPath} fill="none" stroke="#5ba8a0" strokeWidth="2.2" strokeLinecap="round" />

              {/* مؤشر الآن */}
              <line x1={nowX} x2={nowX} y1={MT} y2={H - MB} stroke="rgba(252,225,182,0.14)" strokeDasharray="2 4" />
              <circle cx={nowX} cy={yP(pNow)} r="6" fill="#5ba8a0" filter="url(#glow)" />
              <circle cx={nowX} cy={yP(pNow)} r="11" fill="none" stroke="#5ba8a0" strokeWidth="1" opacity="0.4" />
              <text
                x={Math.min(Math.max(nowX, MR + 70), W - ML - 70)}
                y={yP(pNow) - 16}
                textAnchor="middle"
                fontSize="12"
                fill="#9fd4ce"
              >
                لو توقفت الآن: ≈ {arNum(pNow)} دقيقة أثر
              </text>
            </>
          )}

          {/* محور الزمن */}
          <line x1={MR} x2={W - ML} y1={H - MB} y2={H - MB} stroke="rgba(252,225,182,0.18)" />
          {xTicks.map((t) => (
            <g key={t}>
              <line x1={x(t)} x2={x(t)} y1={H - MB} y2={H - MB + 5} stroke="rgba(252,225,182,0.18)" />
              <text x={x(t)} y={H - MB + 18} textAnchor="middle" fontSize="10" fill="rgba(242,237,226,0.4)">
                {arNum(t)}
              </text>
            </g>
          ))}
        </svg>
      </div>

      {/* وسيلة الإيضاح */}
      <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-[11px] text-[--ink-dim]">
        {mode === 'freq' ? (
          <>
            <span className="flex items-center gap-2">
              <span className="inline-block h-[2px] w-6 rounded" style={{ background: 'linear-gradient(to left,#d98a6a,#5ba8a0)' }} />
              مسار جلستك الفعلي
            </span>
            <span className="flex items-center gap-2">
              <span className="inline-block h-[2px] w-6 border-t-2 border-dotted border-[#fce1b6]/40" />
              المنحنى النموذجي المتوقع
            </span>
            <span className="flex items-center gap-2">
              <span className="inline-block h-[2px] w-6 border-t-2 border-dashed" style={{ borderColor: meta.color }} />
              إسقاط زوال الأثر لو توقفت الآن
            </span>
          </>
        ) : (
          <span>
            كل نقطة على المنحنى تجيب: «لو واصلت التسبيح حتى هذه اللحظة ثم توقفت، كم دقيقة يبقى أثر الهدوء؟»
          </span>
        )}
      </div>
    </section>
  )
}
